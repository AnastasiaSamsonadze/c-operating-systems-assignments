#include "stdio.h"
#include "stdlib.h"

void addPoem(char fileName[], char poem[]) {
    /*
        insertion of a poem by printing the
        string into a file via 'append' option
        specified in the FILE pointer
    */
    FILE *f = fopen(fileName, "a");

    if (f == NULL) {
        printf("Unable to open a file!");
        exit(1);
    }

    fprintf(f, "%s\n", poem);
    fclose(f);
}

void removePoem(char fileName[], int target) {
    /*
        removal of poem in a way of copying everything
        except the targeted line back to the original file
        using temporary file as an additional storage
    */
    char line[1000];
    char copyName[1000];

    FILE *file, *copy;
    sprintf(copyName, "%s.tmp", fileName);

    // 1) move content from file (original file)
    //    to copy (temporary file)
    file = fopen(fileName, "r");
    copy = fopen(copyName, "w");

    if (file == NULL || copy == NULL) {
        printf("Unable to open a file! Remove aborted...");
        exit(1);
    }

    while (fgets(line, 1000, file)) {
        fprintf(copy, "%s", line);
    }
    fclose(file);
    fclose(copy);

    // 2) copy everything, except target line
    //    back to the original file
    copy = fopen(copyName, "r");
    file = fopen(fileName, "w");

    if (file == NULL || copy == NULL) {
        printf("Unable to open a file! Remove aborted...");
        exit(1);
    }

    int index = 0;
    while (fgets(line, 1000, copy)) {
        if (++index != target) {
            fprintf(file, "%s", line);
        }
    }
    fclose(file);
    fclose(copy);
}

void listPoems(char fileName[]) {
    /*
        open file, then show each line with
        corresponding index, that starts from 1 (0++...)
    */
    FILE *f = fopen(fileName, "r");
    char line[1000];
    int index = 0;
    
    while (fgets(line, 1000, f)) {
        printf("%d) %s", ++index, line);
    }
    fclose(f);
}



int main() {
    /*
        str filename -> name of file where poems are stored
        str input ----> entered 'poem' text for case 1 (add poem) 
        int N --------> selected 'index' value for case 2 (remove poem)
        int O --------> menu option that is chosen by user 
    */
    char fileName[] = "poems.txt";
    char input[1000];
    int o, n;

    do {
        printf("\n----Menu----\n");
        printf("0. Close menu, exit app\n");
        printf("1. Add a poem\n");
        printf("2. Remove a poem\n");
        printf("3. List a poem\n");
        printf("Select your option: ");
        scanf("%d", &o);

        switch (o) {
            case 0:
                printf("Closing the application...\n");
                break; // skip, but not invalidate menu option
            case 1:
                printf("Add poem\n");
                printf("Enter a poem: ");
                scanf("%s", input);
                addPoem(fileName, input);
                break;
            case 2:
                printf("Remove poem\n");
                listPoems(fileName);
                printf("Select a poem by number: ");
                scanf("%d", &n);
                removePoem(fileName, n);
                break;
            case 3: 
                printf("List poem\n");
                listPoems(fileName);
                break;
            default: 
                printf("Unrecognized option. Choose a number from the menu!");
                break;
        }

    } while (o != 0);

    printf("\n"); // extra symbol to prevent any text from being in the prompt.
    return 0;
}

