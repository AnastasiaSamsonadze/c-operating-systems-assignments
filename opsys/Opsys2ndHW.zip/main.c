#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "time.h"
#include "unistd.h"
#include "sys/ipc.h"
#include "sys/msg.h"

#define MAX_POEM_LENGTH 512
#define POEM_COUNT 3

// Message structure to hold two poems and the type identifier
struct message
{
    long type;                      // Message type to identify the target bunny boy
    char poems[2][MAX_POEM_LENGTH]; // Array to hold two poems
};

// Loads one-line poems from a file into an array
void load_poems(char poems[POEM_COUNT][MAX_POEM_LENGTH])
{
    FILE *file = fopen("poems.txt", "r");
    if (!file)
    {
        perror("Unable to open poems file");
        exit(1);
    }
    for (int i = 0; i < POEM_COUNT; i++)
    {
        // Read one line into the poems array
        if (fgets(poems[i], MAX_POEM_LENGTH, file) == NULL)
        {
            perror("Failed to read poem");
            exit(1);
        }
        // Remove the newline character at the end
        poems[i][strcspn(poems[i], "\n")] = 0;
    }
    fclose(file); // Close the file after reading
}

// Conditionally appends "Happy Easter!" to the given poem
void modify_poem(char *poem, int index)
{
    // 50% chance of modifying the poem
    printf("\n");
    if (rand() % 2 == 0)
    {
        strcat(poem, " Happy Easter!");
        if (index == 0)
        {
            printf("Mama Bunny modified the first poem.\n");
        }
        else
        {
            printf("Mama Bunny modified the second poem.\n");
        }
    }
    else
    {
        if (index == 0)
        {
            printf("Mama Bunny left the first poem unchanged.\n");
        }
        else
        {
            printf("Mama Bunny left the second poem unchanged.\n");
        }
    }
}

// Sends two poems through a message queue to the selected bunny boy
void send_poems(int queue_id, int boy, char poems[2][MAX_POEM_LENGTH])
{
    struct message msg = {boy + 1, {""}};
    strcpy(msg.poems[0], poems[0]);
    strcpy(msg.poems[1], poems[1]);
    printf("\nMama Bunny is sending two poems to Bunny Boy %d.\n\n", boy + 1);
    if (msgsnd(queue_id, &msg, sizeof(msg.poems), 0) == -1)
    {
        perror("msgsnd failed");
        exit(1);
    }
}

// Receives poems from the message queue and prints the selected poem
void receive_poem(int queue_id, int boy)
{
    struct message msg;
    if (msgrcv(queue_id, &msg, sizeof(msg.poems), boy + 1, 0) == -1)
    {
        perror("msgrcv failed");
        exit(1);
    }
    int chosen_poem = rand() % 2; // Randomly select one of the two poems
    printf("Bunny Boy %d received poem:\n-----------\n%s\nMay I water!\n-----------", boy + 1, msg.poems[chosen_poem]);
}

void addPoem(char fileName[], char poem[])
{
    /*
        insertion of a poem by printing the
        string into a file via 'append' option
        specified in the FILE pointer
    */
    FILE *f = fopen(fileName, "a");

    if (f == NULL)
    {
        printf("Unable to open a file!");
        exit(1);
    }

    fprintf(f, "%s\n", poem);
    fclose(f);
}

void removePoem(char fileName[], int target)
{
    /*
        removal of poem in a way of copying everything
        except the targeted line back to the original file
        using temporary file as an additional storage
    */
    char line[1000];
    char copyName[1000];

    FILE *file, *copy;
    sprintf(copyName, "%s.tmp", fileName);

    // 1) move content from file (original file)
    //    to copy (temporary file)
    file = fopen(fileName, "r");
    copy = fopen(copyName, "w");

    if (file == NULL || copy == NULL)
    {
        printf("Unable to open a file! Remove aborted...");
        exit(1);
    }

    while (fgets(line, 1000, file))
    {
        fprintf(copy, "%s", line);
    }
    fclose(file);
    fclose(copy);

    // 2) copy everything, except target line
    //    back to the original file
    copy = fopen(copyName, "r");
    file = fopen(fileName, "w");

    if (file == NULL || copy == NULL)
    {
        printf("Unable to open a file! Remove aborted...");
        exit(1);
    }

    int index = 0;
    while (fgets(line, 1000, copy))
    {
        if (++index != target)
        {
            fprintf(file, "%s", line);
        }
    }
    fclose(file);
    fclose(copy);
}

void listPoems(char fileName[])
{
    /*
        open file, then show each line with
        corresponding index, that starts from 1 (0++...)
    */
    FILE *f = fopen(fileName, "r");
    char line[1000];
    int index = 0;

    while (fgets(line, 1000, f))
    {
        printf("%d) %s", ++index, line);
    }
    fclose(f);
}

void modifyPoem(const char *fileName, int index, const char *newPoem)
{
    FILE *f = fopen(fileName, "r");
    if (f == NULL)
    {
        printf("Error opening file\n");
        return;
    }

    char lines[1000][1000];
    int i = 0;

    while (fgets(lines[i], sizeof(lines[i]), f))
    {
        lines[i][strcspn(lines[i], "\n")] = 0; // remove newline character
        i++;
    }
    fclose(f);

    if (index < 1 || index > i)
    {
        printf("Invalid index\n");
        return;
    }

    strcpy(lines[index - 1], newPoem); // replace the poem at the given index

    f = fopen(fileName, "w");
    if (f == NULL)
    {
        printf("Error opening file\n");
        return;
    }

    for (int j = 0; j < i; j++)
    {
        fprintf(f, "%s\n", lines[j]);
    }
    fclose(f);
}

void waterPoems()
{
    char poems[POEM_COUNT][MAX_POEM_LENGTH];
    load_poems(poems); // Load the poems from the file

    // Create a message queue for interprocess communication
    int queue_id = msgget(IPC_PRIVATE, 0666 | IPC_CREAT);
    if (queue_id == -1)
    {
        perror("msgget failed");
        exit(1);
    }

    srand(time(NULL));              // Seed the random number generator
    int bunny_boy = rand() % 4 + 1; // Randomly select a bunny boy (1-based index)

    // Fork a new process to simulate the bunny boy's activities
    pid_t pid = fork();
    if (pid == 0)
    {
        // Child process: receive and recite a poem, then simulate watering
        receive_poem(queue_id, bunny_boy - 1); // Convert to 0-based index
        printf("\nBunny Boy %d: Waters the girls in Barátfa\n", bunny_boy);
        exit(0);
    }

    // Parent process: select and modify two random poems
    sleep(1); // Ensure the child process is ready
    char selected_poems[2][MAX_POEM_LENGTH];
    strcpy(selected_poems[0], poems[rand() % POEM_COUNT]);
    modify_poem(selected_poems[0], 0);
    strcpy(selected_poems[1], poems[rand() % POEM_COUNT]);
    modify_poem(selected_poems[1], 1);

    // Send the modified poems to the bunny boy via the message queue
    send_poems(queue_id, bunny_boy - 1, selected_poems);

    // Wait for the child process to finish and clean up the message queue
    wait(NULL);
    msgctl(queue_id, IPC_RMID, NULL);
}

int main()
{
    /*
        str filename -> name of file where poems are stored
        str input ----> entered 'poem' text for case 1 (add poem)
        int N --------> selected 'index' value for case 2 (remove poem)
        int O --------> menu option that is chosen by user
    */
    char fileName[] = "poems.txt";
    char input[1000];
    int o, n;

    do
    {
        printf("\n----Menu----\n");
        printf("0. Close menu, exit app\n");
        printf("1. Add a poem\n");
        printf("2. Remove a poem\n");
        printf("3. List a poem\n");
        printf("4. Modify a poem\n");
        printf("5. Water poems\n");
        printf("Select your option: ");
        scanf("%d", &o);
        // clearing the buffer not to add a new line to txt
        while (getchar() != '\n')
            ;

        switch (o)
        {
        case 0:
            printf("Closing the application...\n");
            break; // skip, but not invalidate menu option
        case 1:
            printf("Add poem\n");
            printf("Enter a poem: ");
            // not scanf bc it reads a string until a whitespace, but we dont need that.
            // fgets reads until encounters a new line char = \n
            fgets(input, sizeof(input), stdin);
            // removing new line char from the string, to add line after a line without new line between them
            input[strcspn(input, "\n")] = 0;
            addPoem(fileName, input);
            break;
        case 2:
            printf("Remove poem\n");
            listPoems(fileName);
            printf("\nSelect a poem by number: ");
            scanf("%d", &n);
            removePoem(fileName, n);
            break;
        case 3:
            printf("List poem\n");
            listPoems(fileName);
            break;
        case 4:
            printf("Enter the index of the poem to modify: ");
            scanf("%d", &n);
            while ((getchar()) != '\n')
                ; // clear input buffer
            printf("Enter the new poem: ");
            fgets(input, sizeof(input), stdin);
            input[strcspn(input, "\n")] = 0; // remove newline character

            modifyPoem(fileName, n, input);
            break;
        case 5:
            waterPoems();
            break;
        default:
            printf("Unrecognized option. Choose a number from the menu!");
            break;
        }

    } while (o != 0);

    printf("\n"); // extra symbol to prevent any text from being in the prompt.
    return 0;
}
